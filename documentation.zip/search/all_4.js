var searchData=
[
  ['targetarduinoid',['TargetArduinoID',['../class_peer_i_o_serial_control.html#aeb1dcf1472d63a4c7c900a36842f7598',1,'PeerIOSerialControl::TargetArduinoID(int ID)'],['../class_peer_i_o_serial_control.html#aec51821dd28c24b2b1cd90b7d574a262',1,'PeerIOSerialControl::TargetArduinoID()']]],
  ['timeout',['Timeout',['../class_peer_i_o_serial_control.html#a9f9d4816bfdb7cb3967d98cd66f3e9c8',1,'PeerIOSerialControl::Timeout(int milliseconds)'],['../class_peer_i_o_serial_control.html#abf20bce54a73c68e33a24c88df1319f7',1,'PeerIOSerialControl::Timeout()']]]
];
