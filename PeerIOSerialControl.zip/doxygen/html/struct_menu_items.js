var struct_menu_items =
[
    [ "Alarm", "struct_menu_items.html#add9f55ff02e100945341ebd066ec411f", null ],
    [ "AlarmCompare", "struct_menu_items.html#aacb3640f55b41ae6729388f5efd4ec6d", null ],
    [ "AlarmValueIdx", "struct_menu_items.html#aa189ad4c4495ec7c5e7fd5fc42cc7df2", null ],
    [ "Analog", "struct_menu_items.html#a4da1aa5d62df1895500376519e185222", null ],
    [ "LastOption", "struct_menu_items.html#acac43e5e995be73e93e41029779fb106", null ],
    [ "Option", "struct_menu_items.html#ae39c1330acc0729054c2258096931125", null ],
    [ "Pin", "struct_menu_items.html#a089b8454f4ee345bfd23c4e69c7c9b9b", null ],
    [ "Poll", "struct_menu_items.html#a87995f1e229c08f222f9b64cb4a224a9", null ],
    [ "Text", "struct_menu_items.html#afe3af59788c6505e6699bb5bf92821aa", null ],
    [ "Value", "struct_menu_items.html#a067abc2047b8a75b375529f392894156", null ],
    [ "ValueLocation", "struct_menu_items.html#ab637dbabb22a96de413942dc24b38820", null ],
    [ "ValueSettable", "struct_menu_items.html#a1481d6951156092bca3d8fd26111300e", null ],
    [ "ValueSettingNow", "struct_menu_items.html#a6726d313ef1dd05c5bdb207ba29892e3", null ],
    [ "ValueSetTo", "struct_menu_items.html#ae1932cdd55fe6118e9701d24886f6669", null ],
    [ "ValueValid", "struct_menu_items.html#a3ca523773724f36adc38e00445b89ef7", null ]
];