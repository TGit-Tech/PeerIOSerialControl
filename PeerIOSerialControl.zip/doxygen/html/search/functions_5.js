var searchData=
[
  ['timeout',['Timeout',['../class_peer_i_o_serial_control.html#a9f9d4816bfdb7cb3967d98cd66f3e9c8',1,'PeerIOSerialControl::Timeout(int milliseconds)'],['../class_peer_i_o_serial_control.html#abf20bce54a73c68e33a24c88df1319f7',1,'PeerIOSerialControl::Timeout()']]]
];
