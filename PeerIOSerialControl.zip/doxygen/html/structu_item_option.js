var structu_item_option =
[
    [ "DrivePin", "structu_item_option.html#a04d15d9ba9689a5a095f50e87163ab07", null ],
    [ "PumpID", "structu_item_option.html#a74b5023441d4cafda32307af530c1cba", null ],
    [ "Text", "structu_item_option.html#a3c3c5fdbecc30b6373a05d373105201d", null ]
];