var class_remote_arduino =
[
    [ "RemoteArduino", "class_remote_arduino.html#a659f482a86a7fe81fc595359d33fd229", null ],
    [ "Pin", "class_remote_arduino.html#a7aab90af171a79f74ab55b055b2705ba", null ],
    [ "Update", "class_remote_arduino.html#ae22d5aa3c69c8200a96c235309c323a3", null ]
];