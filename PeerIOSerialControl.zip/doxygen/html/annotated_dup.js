var annotated_dup =
[
    [ "ArduinoPin", "class_arduino_pin.html", "class_arduino_pin" ],
    [ "MenuItems", "struct_menu_items.html", "struct_menu_items" ],
    [ "PeerIOSerialControl", "class_peer_i_o_serial_control.html", "class_peer_i_o_serial_control" ],
    [ "RemoteArduino", "class_remote_arduino.html", "class_remote_arduino" ],
    [ "uItemOption", "structu_item_option.html", "structu_item_option" ]
];