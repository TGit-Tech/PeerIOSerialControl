var files =
[
    [ "all_0.js", "all__0_8js_source.html", null ],
    [ "all_1.js", "all__1_8js_source.html", null ],
    [ "all_2.js", "all__2_8js_source.html", null ],
    [ "all_3.js", "all__3_8js_source.html", null ],
    [ "all_4.js", "all__4_8js_source.html", null ],
    [ "classes_0.js", "classes__0_8js_source.html", null ],
    [ "classes_1.js", "classes__1_8js_source.html", null ],
    [ "classes_2.js", "classes__2_8js_source.html", null ],
    [ "dynsections.js", "dynsections_8js_source.html", null ],
    [ "functions_0.js", "functions__0_8js_source.html", null ],
    [ "functions_1.js", "functions__1_8js_source.html", null ],
    [ "functions_2.js", "functions__2_8js_source.html", null ],
    [ "HandRemote.ino", "_hand_remote_8ino_source.html", null ],
    [ "jquery.js", "jquery_8js_source.html", null ],
    [ "PeerIOSerialControl.cpp", "_peer_i_o_serial_control_8cpp.html", "_peer_i_o_serial_control_8cpp" ],
    [ "PeerIOSerialControl.h", "_peer_i_o_serial_control_8h.html", "_peer_i_o_serial_control_8h" ],
    [ "RemoteArduino.cpp", "_remote_arduino_8cpp_source.html", null ],
    [ "RemoteArduino.h", "_remote_arduino_8h_source.html", null ],
    [ "search.js", "search_8js_source.html", null ],
    [ "searchdata.js", "searchdata_8js_source.html", null ],
    [ "Settings.h", "_settings_8h_source.html", null ]
];