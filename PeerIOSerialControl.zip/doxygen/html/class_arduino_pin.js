var class_arduino_pin =
[
    [ "ExpireTime", "class_arduino_pin.html#a0d9f9dabd29855ff7e226a0f55084573", null ],
    [ "Value", "class_arduino_pin.html#ab8cf772d35786878fc6a2b2f607e9b9c", null ]
];